/// <reference types="@types/googlemaps" />
import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { MapsAPILoader} from '@agm/core';

import { FormControl } from '@angular/forms';
import { ThrowStmt } from '@angular/compiler';
 declare let google:any;


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  @ViewChild('search')
   public searchElementRef : ElementRef;
   public zoom: number=8;
   public latitude: number;
   public longitude: number;
   public latlongs: any = [];
   public latlong: any = {};
   public searchControl: FormControl;
   public placeID : String;
   

  constructor(private mapsAPILoader : MapsAPILoader, private ngZone: NgZone) { }

  ngOnInit() {
    this.zoom=8;
    this.latitude ;
    this.longitude;
    this.searchControl=new FormControl();
    this.setCurrentPosition() ;
    
    this.mapsAPILoader.load().then( () => {
      const autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement,{
        types: [],
    
      });
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run( () => {
          
          const place:google.maps.places.PlaceResult = autocomplete.getPlace();
          this.placeID = place.place_id;
          if(place.geometry === undefined || place.geometry === null){
            return;
          }
          const latlong={
            latitude: place.geometry.location.lat(),
            longitude: place.geometry.location.lng(),
          };
          this.latlongs.push(latlong);
          this.searchControl.reset();

        });
      });
    });
    
  }

  private setCurrentPosition(){
    if('geolocation' in navigator){
      navigator.geolocation.getCurrentPosition((position) =>{
        this.latitude=position.coords.latitude;
        this.longitude=position.coords.longitude;
        this.zoom=8;
      });
    }
  }

 
      

}
